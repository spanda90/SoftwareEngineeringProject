
public interface Account 
{
	public abstract void accept(Visitor v);
	public void addAccount(Account account);
	
}





