package singleton;

public class Client 
{
	Account a;

}
