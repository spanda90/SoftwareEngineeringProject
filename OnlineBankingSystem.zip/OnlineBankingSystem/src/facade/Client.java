package facade;

public interface Client 
{

}
