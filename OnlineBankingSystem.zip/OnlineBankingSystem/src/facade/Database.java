package facade;

public interface Database {

}
