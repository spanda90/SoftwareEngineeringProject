package facade;

public class Facade implements Client
{
	Account a;
	Database d;
	
	public void accountOperations(){}
	
	
}
