package facade;

public interface Account {

}
